//
//  WorkerCell.swift
//  straw
//
//  Created by quang on 7/8/16.
//  Copyright © 2016 slifer7. All rights reserved.
//

import UIKit

class WorkerCell : UITableViewCell{
    @IBOutlet weak var lblWorkerName: UILabel!
    @IBOutlet weak var lblInfo: UILabel!
}
