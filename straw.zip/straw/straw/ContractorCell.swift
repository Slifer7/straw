//
//  ContractorCell.swift
//  straw
//
//  Created by quang on 7/8/16.
//  Copyright © 2016 slifer7. All rights reserved.
//

import UIKit

class ContractorCell: UITableViewCell{
    @IBOutlet weak var lblContractor: UILabel!
    @IBOutlet weak var lblInfo: UILabel!
}
