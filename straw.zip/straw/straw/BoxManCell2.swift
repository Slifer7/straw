//
//  BoxManCell.swift
//  straw
//
//  Created by quang on 7/7/16.
//  Copyright © 2016 slifer7. All rights reserved.
//

import UIKit

class BoxManCell2: UITableViewCell {
    
    @IBOutlet weak var txtWorkerName: UILabel!
    
    @IBOutlet weak var txtBox250: UILabel!
    @IBOutlet weak var txtLastActionTime250: UILabel!
    
    @IBOutlet weak var txtBox500: UILabel!
    @IBOutlet weak var txtLastActionTime500: UILabel!
    
    @IBOutlet weak var txtBox1: UILabel!
    @IBOutlet weak var txtLastActionTime1: UILabel!
    
}
