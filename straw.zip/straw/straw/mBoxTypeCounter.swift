//
//  Worker.swift
//  straw
//
//  Created by quang on 7/7/16.
//  Copyright © 2016 slifer7. All rights reserved.
//
import SQLite

class mBoxTypeCounter{
    var BoxType = "" // 250g 500g or 1kg
    var boxNoList = [String]() // Dùng khi thống kê
}